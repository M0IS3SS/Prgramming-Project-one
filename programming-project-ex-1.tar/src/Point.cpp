#include "Point.h"
#include <GL/freeglut.h>
#include <iostream>

using namespace std;

Point::Point() {
    x = 0.0;
    y = 0.0;
    c = Color(255, 0, 0);
    size = 7;
}

Point::Point(float x, float y) : Point() {
    this->x = x;
    this->y = y;
    }

   Point::Point(float x, float y,  Color c, int size) : Point(x, y, c){
    this->size = size;
   }

void Point::draw() const {
    glColor3f(c.getR(), c.getG(), c.getB());
    glPointSize(size);

    glBegin(GL_POINT);
        glVertex2f(x,y);
    glEnd();
}

float Point::getX() const{
    return x;
}

float Point::getY() const{
    return y;
}

float Point::getSize() const{
    return size;
}