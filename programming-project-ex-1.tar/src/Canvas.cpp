#include "Canvas.h"
#include <GL/freeglut.h>

Canvas::Canvas(int x, int y, int w, int h) : Canvas_(x,y,w,h){
    //
}

void Canvas::addPoint(float x, float y, float r, float g, float b, int size){
    points.push_back(new(x,y,r,g,b, size));
}

void Canvas::render(){
    for(unsigned int i =0; i < point.size(); i++){
        point[i]->draw();
    }
}