#ifndef POINT_H
#define POINT_H
#include "Color.h"


class Point{
    int x;
    int y;
    Color c;
    int size;

    Point();
    Point(float x, float y);
    Point(float x, float y, Color c);
    Point(float x, float y, Color c, float size);

    void draw() const;

    float getX() const;
    float getY() const;
    float getSize() const;




};

#endif