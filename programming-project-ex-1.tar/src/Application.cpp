#include "Application.h"

using namespace bobcat;
using namespace std;

void Application::onCanvasMouseDown(bobcat::Widget* sender, float mx, float my){

}

Application::Application() {


    
    window = new Window(100, 100, 400, 400, "Paint Application");
    ON_MOUSE_DOWN(canvas, Application::onCanvasMouseDown);

    window-add(canvas);
    window->show();
}